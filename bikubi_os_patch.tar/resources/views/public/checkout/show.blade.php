@extends('layouts.app')

@section('title', ($scenario['label'] ?? 'Оформление заказа').' — BiKuBe')

@section('content')
<section style="min-height:100vh;background:#071018;color:#f8fafc;padding:48px 16px;">
    <div style="max-width:980px;margin:0 auto;">
        <a href="{{ route('public.category', ['slug' => $scenario['service_domain'] === 'delivery' ? 'delivery' : $scenario['service_domain']]) }}" style="color:#8ee63f;text-decoration:none;">← Вернуться к категории</a>

        <div style="display:grid;grid-template-columns:minmax(0,1.1fr) minmax(300px,.75fr);gap:28px;align-items:start;margin-top:22px;">
            <div style="background:#0d1822;border:1px solid rgba(255,255,255,.1);border-radius:18px;padding:28px;">
                <p style="color:#8ee63f;font-weight:700;margin:0 0 8px;">{{ $scenario['code'] }}</p>
                <h1 style="font-size:clamp(30px,5vw,54px);line-height:1;margin:0 0 16px;">{{ $scenario['label'] }}</h1>
                <p style="color:#b8c4d6;font-size:17px;line-height:1.6;margin-bottom:26px;">
                    Единый Order Engine создаст заказ, рассчитает базовую стоимость, сохранит scenario metadata и передаст заявку в операционный центр.
                </p>

                @auth
                    <form method="POST" action="{{ route('checkout.store', ['scenario' => $scenario['code']]) }}" style="display:grid;gap:16px;">
                        @csrf
                        <label>
                            <span style="display:block;color:#dbe7f6;margin-bottom:6px;">Адрес получения</span>
                            <input name="pickup_address" value="{{ old('pickup_address') }}" placeholder="Магазин, ресторан или адрес отправления" style="width:100%;box-sizing:border-box;border:1px solid rgba(255,255,255,.16);background:#09131d;color:#fff;border-radius:12px;padding:14px;">
                        </label>
                        <label>
                            <span style="display:block;color:#dbe7f6;margin-bottom:6px;">Адрес доставки</span>
                            <input name="delivery_address" value="{{ old('delivery_address') }}" placeholder="Куда доставить заказ" style="width:100%;box-sizing:border-box;border:1px solid rgba(255,255,255,.16);background:#09131d;color:#fff;border-radius:12px;padding:14px;">
                        </label>
                        <label>
                            <span style="display:block;color:#dbe7f6;margin-bottom:6px;">Время / слот</span>
                            <input name="delivery_window" value="{{ old('delivery_window') }}" placeholder="Сегодня, как можно быстрее" style="width:100%;box-sizing:border-box;border:1px solid rgba(255,255,255,.16);background:#09131d;color:#fff;border-radius:12px;padding:14px;">
                        </label>
                        <label>
                            <span style="display:block;color:#dbe7f6;margin-bottom:6px;">Комментарий</span>
                            <textarea name="notes" rows="5" placeholder="Что купить, где забрать, детали подъезда, этаж, вес..." style="width:100%;box-sizing:border-box;border:1px solid rgba(255,255,255,.16);background:#09131d;color:#fff;border-radius:12px;padding:14px;">{{ old('notes') }}</textarea>
                        </label>
                        <label style="display:flex;gap:10px;align-items:center;color:#dbe7f6;">
                            <input type="checkbox" name="is_urgent" value="1">
                            Срочная заявка
                        </label>
                        <button type="submit" style="border:0;border-radius:14px;background:#8ee63f;color:#071018;font-weight:900;padding:16px 20px;cursor:pointer;">
                            Создать заказ в Order Engine
                        </button>
                    </form>
                @else
                    <div style="background:#101f2c;border:1px solid rgba(142,230,63,.35);border-radius:16px;padding:20px;">
                        <p style="margin-top:0;color:#dbe7f6;">Чтобы создать заказ и отслеживать его в кабинете, войдите или зарегистрируйтесь.</p>
                        <a href="{{ route('login') }}" style="display:inline-block;background:#8ee63f;color:#071018;font-weight:900;text-decoration:none;border-radius:12px;padding:12px 18px;">Войти</a>
                        <a href="{{ route('register') }}" style="display:inline-block;color:#8ee63f;font-weight:800;text-decoration:none;margin-left:12px;">Регистрация</a>
                    </div>
                @endauth
            </div>

            <aside style="background:#0d1822;border:1px solid rgba(255,255,255,.1);border-radius:18px;padding:24px;">
                <h2 style="margin:0 0 18px;">Операционный паспорт</h2>
                <dl style="display:grid;gap:14px;margin:0;">
                    <div><dt style="color:#7d8ca3;">Домен</dt><dd style="margin:3px 0 0;font-weight:800;">{{ $scenario['service_domain'] }}</dd></div>
                    <div><dt style="color:#7d8ca3;">Исполнитель</dt><dd style="margin:3px 0 0;font-weight:800;">{{ $scenario['worker_type'] ?? 'worker' }}</dd></div>
                    <div><dt style="color:#7d8ca3;">SLA</dt><dd style="margin:3px 0 0;font-weight:800;">{{ $scenario['sla_minutes'] ?? 90 }} мин</dd></div>
                    <div><dt style="color:#7d8ca3;">Оценка</dt><dd style="margin:3px 0 0;font-weight:800;">{{ number_format($estimate['total_amount'] ?? 0, 0, '.', ' ') }} {{ $estimate['currency'] ?? 'NOK' }}</dd></div>
                </dl>
                <div style="margin-top:22px;padding-top:18px;border-top:1px solid rgba(255,255,255,.1);color:#9fb0c7;line-height:1.55;">
                    После создания заказ появится в Filament Operations Center и у подходящих исполнителей в `/lk`.
                </div>
            </aside>
        </div>
    </div>
</section>
@endsection
