<?php

namespace App\Filament\Pages;

use App\Filament\Pages\AgentTeamChat;
use App\Filament\Pages\UnifiedOperationsCore;
use Filament\Pages\Actions\Action;
use Filament\Pages\Dashboard as BaseDashboard;

class Dashboard extends BaseDashboard
{
    protected static ?string $navigationIcon = 'heroicon-o-home';

    protected static ?string $navigationLabel = 'Операционный центр';

    protected static ?string $navigationGroup = 'Операции';

    protected static ?int $navigationSort = 1;

    protected function getActions(): array
    {
        return [
            Action::make('operations_core')
                ->label('Unified Operations Core')
                ->url(fn () => UnifiedOperationsCore::getUrl())
                ->color('success')
                ->button(),
            Action::make('agent_chat')
                ->label('Командный чат')
                ->url(fn () => AgentTeamChat::getUrl())
                ->color('primary')
                ->button(),
        ];
    }

    protected function getWidgets(): array
    {
        return [];
    }
}
