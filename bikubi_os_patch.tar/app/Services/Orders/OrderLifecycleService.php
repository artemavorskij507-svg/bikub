<?php

namespace App\Services\Orders;

use App\Enums\OrderStatus;
use App\Models\Order;
use Illuminate\Support\Facades\Log;
use InvalidArgumentException;

class OrderLifecycleService
{
    public function transition(Order $order, string $status, ?int $actorId = null, array $context = []): Order
    {
        $status = OrderStatus::normalize($status);

        if (! in_array($status, OrderStatus::allAcceptedValues(), true)) {
            throw new InvalidArgumentException("Unsupported order status [{$status}].");
        }

        $from = (string) $order->status;

        $order->status = $status;

        if ($status === OrderStatus::InProgress->value && ! $order->started_at) {
            $order->started_at = now();
        }

        if ($status === OrderStatus::Completed->value && ! $order->completed_at) {
            $order->completed_at = now();
        }

        $metadata = (array) ($order->metadata ?? []);
        $metadata['lifecycle'][] = [
            'from' => $from,
            'to' => $status,
            'actor_id' => $actorId,
            'context' => $context,
            'changed_at' => now()->toIso8601String(),
        ];
        $order->metadata = $metadata;
        $order->save();

        Log::info('Order lifecycle transition', [
            'order_id' => $order->id,
            'from' => $from,
            'to' => $status,
            'actor_id' => $actorId,
        ]);

        return $order->fresh();
    }
}
