<?php

namespace App\Services\Orders;

use App\Enums\OrderStatus;
use App\Models\Order;
use App\Models\User;
use App\Services\Delivery\OrderFactory as DeliveryOrderFactory;
use Illuminate\Support\Facades\DB;

class UnifiedOrderEngine
{
    public function __construct(
        private readonly OrderScenarioRegistry $scenarios,
        private readonly OrderPricingCoordinator $pricing,
        private readonly ?DeliveryOrderFactory $deliveryOrderFactory = null,
    ) {}

    public function create(string $scenarioCode, User $user, array $payload): Order
    {
        $scenario = $this->scenarios->get($scenarioCode);
        $price = $this->pricing->estimate($scenario, $payload);

        return DB::transaction(function () use ($scenario, $scenarioCode, $user, $payload, $price): Order {
            if (($scenario['service_domain'] ?? null) === 'delivery' && $this->deliveryOrderFactory) {
                $deliveryOrder = $this->deliveryOrderFactory->create(
                    $scenario['delivery_type'],
                    $user,
                    $this->normalizeDeliveryPayload($payload),
                    ['total' => $price['total_amount']],
                );

                $order = $deliveryOrder->order()->firstOrFail();
                $order->forceFill([
                    'service_type' => $scenarioCode,
                    'status' => OrderStatus::WaitingDispatch->value,
                    'total_amount' => $price['total_amount'],
                    'currency' => $price['currency'],
                    'payment_status' => 'pending',
                    'metadata' => $this->mergeEngineMetadata((array) ($order->metadata ?? []), $scenario, $payload, $price),
                ])->save();

                return $order->fresh(['deliveryOrder']);
            }

            return Order::create([
                'user_id' => $user->id,
                'service_type' => $scenarioCode,
                'status' => OrderStatus::WaitingDispatch->value,
                'priority' => ! empty($payload['is_urgent']) ? 'urgent' : 'normal',
                'location' => [
                    'pickup' => $payload['pickup_location'] ?? $payload['current_location'] ?? null,
                    'delivery' => $payload['delivery_location'] ?? null,
                ],
                'scheduled_at' => $payload['scheduled_at'] ?? null,
                'notes' => $payload['notes'] ?? null,
                'total_amount' => $price['total_amount'],
                'currency' => $price['currency'],
                'payment_status' => 'pending',
                'metadata' => $this->mergeEngineMetadata([], $scenario, $payload, $price),
            ]);
        });
    }

    private function normalizeDeliveryPayload(array $payload): array
    {
        return [
            'pickup_location' => $payload['pickup_location'] ?? [
                'address' => $payload['pickup_address'] ?? 'Narvik partner pickup',
            ],
            'delivery_location' => $payload['delivery_location'] ?? [
                'address' => $payload['delivery_address'] ?? $payload['address'] ?? 'Customer address',
            ],
            'pickup_address' => $payload['pickup_address'] ?? null,
            'delivery_address' => $payload['delivery_address'] ?? $payload['address'] ?? null,
            'preferred_delivery_window' => $payload['delivery_window'] ?? $payload['slot'] ?? null,
            'store_id' => $payload['store_id'] ?? null,
            'restaurant_id' => $payload['restaurant_id'] ?? null,
            'items' => $payload['items'] ?? [],
            'notes' => $payload['notes'] ?? null,
            'is_urgent' => (bool) ($payload['is_urgent'] ?? false),
            'substitution_policy' => $payload['substitution_policy'] ?? 'strict',
        ];
    }

    private function mergeEngineMetadata(array $metadata, array $scenario, array $payload, array $price): array
    {
        $metadata['order_engine'] = [
            'scenario' => $scenario['code'],
            'service_domain' => $scenario['service_domain'] ?? null,
            'worker_type' => $scenario['worker_type'] ?? null,
            'sla_minutes' => $scenario['sla_minutes'] ?? null,
            'checkout_payload' => $this->safePayload($payload),
            'pricing' => $price,
            'created_at' => now()->toIso8601String(),
        ];

        return $metadata;
    }

    private function safePayload(array $payload): array
    {
        unset($payload['password'], $payload['token'], $payload['api_key'], $payload['payment_method']);

        return $payload;
    }
}
