<?php

namespace App\Services\Orders;

use InvalidArgumentException;

class OrderScenarioRegistry
{
    public function all(): array
    {
        return config('order_scenarios.scenarios', []);
    }

    public function get(string $code): array
    {
        $scenario = $this->all()[$code] ?? null;

        if (! is_array($scenario)) {
            throw new InvalidArgumentException("Unknown order scenario [{$code}].");
        }

        return ['code' => $code] + $scenario;
    }

    public function exists(string $code): bool
    {
        return isset($this->all()[$code]);
    }

    public function forDomain(string $domain): array
    {
        return array_filter(
            $this->all(),
            static fn (array $scenario): bool => ($scenario['service_domain'] ?? null) === $domain
        );
    }
}
