<?php

namespace App\Services\Orders;

class OrderPricingCoordinator
{
    public function estimate(array $scenario, array $payload): array
    {
        $base = match ($scenario['code'] ?? '') {
            'delivery.groceries' => 79,
            'delivery.meals' => 69,
            'delivery.bulky' => 249,
            'moving.home' => 990,
            'eco.disposal' => 399,
            'handyman.hourly' => 650,
            'tow.emergency' => 1290,
            'personal-task.errand' => 199,
            'classifieds.delivery-request' => 149,
            default => 99,
        };

        $itemsTotal = collect($payload['items'] ?? [])
            ->sum(static fn ($item): float => (float) ($item['price'] ?? 0) * max(1, (int) ($item['quantity'] ?? 1)));

        $total = $base + $itemsTotal;

        return [
            'base_amount' => $base,
            'items_amount' => $itemsTotal,
            'total_amount' => round($total, 2),
            'currency' => config('order_scenarios.default_currency', 'NOK'),
            'estimated_minutes' => (int) ($scenario['sla_minutes'] ?? 90),
        ];
    }
}
