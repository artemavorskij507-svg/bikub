<?php

namespace App\Enums;

enum OrderStatus: string
{
    case Draft = 'draft';
    case Created = 'created';
    case PaymentPending = 'payment_pending';
    case Confirmed = 'confirmed';
    case WaitingDispatch = 'waiting_dispatch';
    case Assigned = 'assigned';
    case WorkerAccepted = 'worker_accepted';
    case InProgress = 'in_progress';
    case Completed = 'completed';
    case Cancelled = 'cancelled';
    case Refunded = 'refunded';
    case Disputed = 'disputed';

    public static function values(): array
    {
        return array_map(static fn (self $status): string => $status->value, self::cases());
    }

    public static function legacyValues(): array
    {
        return ['pending', 'confirmed', 'in_progress', 'completed', 'cancelled'];
    }

    public static function allAcceptedValues(): array
    {
        return array_values(array_unique([...self::values(), ...self::legacyValues()]));
    }

    public static function normalize(string $status): string
    {
        return match ($status) {
            'pending' => self::WaitingDispatch->value,
            default => $status,
        };
    }
}
